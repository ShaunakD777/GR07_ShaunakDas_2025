export const cuisines = [
    {
        "name": "Italian",
        "image": require("../assets/cuisines/Italian.png")
    },
    {
        "name": "Chinese",
        "image": require("../assets/cuisines/Chinese.png")
    },
    {
        "name": "North Indian",
        "image": require("../assets/cuisines/North-Indian.png")
    }
]